#ifndef	___VERSION_LOG_H___
#define	___VERSION_LOG_H___
#define	_VERSION_MAJOR_		0
#define	_VERSION_MINOR_		9
#define	_VERSION_BUILD_		8
#define	_VERSION_LABEL_		'b'
#endif	___VERSION_LOG_H___